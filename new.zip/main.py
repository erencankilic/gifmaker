from PIL import Image

image_path_list = ['1.png', '2.png', '3.png', '4.png', '5.png', '6.png', '7.png', '8.png', '9.png', '10.png',]

image_list = [Image.open(file) for file in image_path_list]

image_list[0].save(
    'guts.gif',
    save_all=True,
    append_images=image_list[1:],
    duration=500,
    loop=0
)